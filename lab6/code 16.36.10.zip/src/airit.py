
def main() -> None:
    """
    The main loop responsible for getting the input details from the user
    and running the AiRIT's simulation.
    :return: None
    """
    pass  # remove this line


if __name__ == '__main__':
    main()